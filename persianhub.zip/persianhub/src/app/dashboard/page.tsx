import Link from 'next/link';

// فاز ۰: پوسته داشبورد. بعد از ساخت احراز هویت و اتصال فروشگاه، داده واقعی جایگزین می‌شود.
const metrics = ['درآمد', 'تعداد سفارش‌ها', 'میانگین ارزش سفارش', 'مشتریان تکراری'];

export default function Dashboard() {
  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">ZT Iran Hub</div>
        <nav aria-label="منوی اصلی">
          <Link href="/dashboard" aria-current="page">نمای کلی</Link>
          <Link href="/dashboard">فروشگاه‌ها</Link>
          <Link href="/dashboard">تحلیل فروش</Link>
          <Link href="/dashboard">بازاریابی هوشمند</Link>
          <Link href="/dashboard">تنظیمات</Link>
        </nav>
      </aside>
      <main className="main">
        <h1>نمای کلی</h1>
        <div className="grid">
          {metrics.map((m) => (
            <div className="card" key={m}>
              <div className="label">{m}</div>
              <div className="value">—</div>
            </div>
          ))}
        </div>
        <div className="card empty">
          <h2>هنوز فروشگاهی متصل نشده است</h2>
          <p>برای دیدن تحلیل فروش، اولین فروشگاه ووکامرس خود را وصل کنید.</p>
          <Link className="btn" href="/dashboard">اتصال فروشگاه</Link>
        </div>
      </main>
    </div>
  );
}
